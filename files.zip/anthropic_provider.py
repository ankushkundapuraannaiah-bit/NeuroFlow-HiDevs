import asyncio
import time
from typing import AsyncGenerator

import anthropic
from anthropic import AsyncAnthropic, RateLimitError

from .base import BaseLLMProvider, ChatMessage, GenerationResult

# Prices in USD per million tokens
ANTHROPIC_PRICE_TABLE: dict[str, dict[str, float]] = {
    "claude-opus-4-5": {"input": 15.00, "output": 75.00},
    "claude-sonnet-4-5": {"input": 3.00, "output": 15.00},
    "claude-haiku-3-5": {"input": 0.80, "output": 4.00},
    "claude-3-opus-20240229": {"input": 15.00, "output": 75.00},
    "claude-3-sonnet-20240229": {"input": 3.00, "output": 15.00},
    "claude-3-haiku-20240307": {"input": 0.25, "output": 1.25},
}

MAX_RETRIES = 3


class AnthropicProvider(BaseLLMProvider):
    def __init__(self, api_key: str, model: str = "claude-haiku-3-5"):
        self.model = model
        self._client = AsyncAnthropic(api_key=api_key)
        self._prices = ANTHROPIC_PRICE_TABLE.get(model, {"input": 0.0, "output": 0.0})

    @property
    def cost_per_input_token(self) -> float:
        return self._prices["input"] / 1_000_000

    @property
    def cost_per_output_token(self) -> float:
        return self._prices["output"] / 1_000_000

    @property
    def context_window(self) -> int:
        windows = {
            "claude-opus-4-5": 200_000,
            "claude-sonnet-4-5": 200_000,
            "claude-haiku-3-5": 200_000,
            "claude-3-opus-20240229": 200_000,
            "claude-3-sonnet-20240229": 200_000,
            "claude-3-haiku-20240307": 200_000,
        }
        return windows.get(self.model, 200_000)

    def _split_messages(
        self, messages: list[ChatMessage]
    ) -> tuple[str | None, list[dict]]:
        """
        Anthropic requires system messages to be passed as a top-level
        `system` parameter, not inside the messages list.
        Returns (system_prompt, non_system_messages).
        """
        system_parts: list[str] = []
        conversation: list[dict] = []

        for msg in messages:
            if msg.role == "system":
                if isinstance(msg.content, str):
                    system_parts.append(msg.content)
                else:
                    # multi-modal system content — join text blocks
                    system_parts.extend(
                        block["text"]
                        for block in msg.content
                        if isinstance(block, dict) and block.get("type") == "text"
                    )
            else:
                conversation.append({"role": msg.role, "content": msg.content})

        system_prompt = "\n\n".join(system_parts) if system_parts else None
        return system_prompt, conversation

    async def _with_retry(self, coro_fn, *args, **kwargs):
        for attempt in range(MAX_RETRIES):
            try:
                return await coro_fn(*args, **kwargs)
            except RateLimitError as exc:
                if attempt == MAX_RETRIES - 1:
                    raise
                retry_after = float(
                    getattr(exc, "retry_after", None)
                    or (exc.response.headers.get("retry-after") if exc.response else None)
                    or 2 ** attempt
                )
                wait = retry_after * (2 ** attempt)
                await asyncio.sleep(wait)

    async def complete(self, messages: list[ChatMessage], **kwargs) -> GenerationResult:
        model = kwargs.pop("model", self.model)
        max_tokens = kwargs.pop("max_tokens", 4096)
        system_prompt, conversation = self._split_messages(messages)

        start = time.monotonic()

        create_kwargs = dict(
            model=model,
            messages=conversation,
            max_tokens=max_tokens,
            **kwargs,
        )
        if system_prompt:
            create_kwargs["system"] = system_prompt

        response = await self._with_retry(
            self._client.messages.create,
            **create_kwargs,
        )

        latency_ms = (time.monotonic() - start) * 1000
        prices = ANTHROPIC_PRICE_TABLE.get(model, self._prices)
        input_tokens = response.usage.input_tokens
        output_tokens = response.usage.output_tokens

        cost_usd = (
            input_tokens * prices["input"] / 1_000_000
            + output_tokens * prices["output"] / 1_000_000
        )

        content = ""
        for block in response.content:
            if hasattr(block, "text"):
                content += block.text

        return GenerationResult(
            content=content,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            latency_ms=latency_ms,
            cost_usd=cost_usd,
            finish_reason=response.stop_reason or "end_turn",
        )

    async def stream(self, messages: list[ChatMessage], **kwargs) -> AsyncGenerator[str, None]:
        model = kwargs.pop("model", self.model)
        max_tokens = kwargs.pop("max_tokens", 4096)
        system_prompt, conversation = self._split_messages(messages)

        create_kwargs = dict(
            model=model,
            messages=conversation,
            max_tokens=max_tokens,
            **kwargs,
        )
        if system_prompt:
            create_kwargs["system"] = system_prompt

        for attempt in range(MAX_RETRIES):
            try:
                async with self._client.messages.stream(**create_kwargs) as stream:
                    async for text in stream.text_stream:
                        yield text
                return
            except RateLimitError as exc:
                if attempt == MAX_RETRIES - 1:
                    raise
                retry_after = float(
                    getattr(exc, "retry_after", None)
                    or (exc.response.headers.get("retry-after") if exc.response else None)
                    or 2 ** attempt
                )
                wait = retry_after * (2 ** attempt)
                await asyncio.sleep(wait)

    async def embed(self, texts: list[str]) -> list[list[float]]:
        # Anthropic does not currently offer a public embeddings API.
        # Raise a clear error so callers can fall back to an OpenAI provider.
        raise NotImplementedError(
            "AnthropicProvider does not support embeddings. "
            "Use OpenAIProvider or a dedicated embedding provider."
        )
