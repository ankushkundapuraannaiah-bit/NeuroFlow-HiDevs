import asyncio
import time
from typing import AsyncGenerator

import openai
from openai import AsyncOpenAI, RateLimitError

from .base import BaseLLMProvider, ChatMessage, GenerationResult

# Prices in USD per million tokens
OPENAI_PRICE_TABLE: dict[str, dict[str, float]] = {
    "gpt-4o": {"input": 2.50, "output": 10.00},
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "gpt-4-turbo": {"input": 10.00, "output": 30.00},
    "gpt-4": {"input": 30.00, "output": 60.00},
    "gpt-3.5-turbo": {"input": 0.50, "output": 1.50},
}

EMBEDDING_MODEL = "text-embedding-3-small"
EMBEDDING_BATCH_SIZE = 100
MAX_RETRIES = 3


class OpenAIProvider(BaseLLMProvider):
    def __init__(self, api_key: str, model: str = "gpt-4o-mini", base_url: str | None = None):
        self.model = model
        self._client = AsyncOpenAI(api_key=api_key, base_url=base_url)
        self._prices = OPENAI_PRICE_TABLE.get(model, {"input": 0.0, "output": 0.0})

    @property
    def cost_per_input_token(self) -> float:
        return self._prices["input"] / 1_000_000

    @property
    def cost_per_output_token(self) -> float:
        return self._prices["output"] / 1_000_000

    @property
    def context_window(self) -> int:
        windows = {
            "gpt-4o": 128_000,
            "gpt-4o-mini": 128_000,
            "gpt-4-turbo": 128_000,
            "gpt-4": 8_192,
            "gpt-3.5-turbo": 16_385,
        }
        return windows.get(self.model, 8_192)

    def _to_openai_messages(self, messages: list[ChatMessage]) -> list[dict]:
        return [{"role": m.role, "content": m.content} for m in messages]

    async def _with_retry(self, coro_fn, *args, **kwargs):
        """Execute coro_fn with exponential backoff on RateLimitError."""
        for attempt in range(MAX_RETRIES):
            try:
                return await coro_fn(*args, **kwargs)
            except RateLimitError as exc:
                if attempt == MAX_RETRIES - 1:
                    raise
                retry_after = float(
                    getattr(exc, "retry_after", None)
                    or exc.response.headers.get("Retry-After", 2 ** attempt)
                )
                wait = retry_after * (2 ** attempt)
                await asyncio.sleep(wait)

    async def complete(self, messages: list[ChatMessage], **kwargs) -> GenerationResult:
        oai_messages = self._to_openai_messages(messages)
        model = kwargs.pop("model", self.model)

        start = time.monotonic()

        response = await self._with_retry(
            self._client.chat.completions.create,
            model=model,
            messages=oai_messages,
            **kwargs,
        )

        latency_ms = (time.monotonic() - start) * 1000
        usage = response.usage
        prices = OPENAI_PRICE_TABLE.get(model, self._prices)

        cost_usd = (
            usage.prompt_tokens * prices["input"] / 1_000_000
            + usage.completion_tokens * prices["output"] / 1_000_000
        )

        return GenerationResult(
            content=response.choices[0].message.content or "",
            model=model,
            input_tokens=usage.prompt_tokens,
            output_tokens=usage.completion_tokens,
            latency_ms=latency_ms,
            cost_usd=cost_usd,
            finish_reason=response.choices[0].finish_reason or "stop",
        )

    async def stream(self, messages: list[ChatMessage], **kwargs) -> AsyncGenerator[str, None]:
        oai_messages = self._to_openai_messages(messages)
        model = kwargs.pop("model", self.model)

        async def _gen():
            async for chunk in await self._client.chat.completions.create(
                model=model,
                messages=oai_messages,
                stream=True,
                **kwargs,
            ):
                delta = chunk.choices[0].delta.content if chunk.choices else None
                if delta:
                    yield delta

        # Wrap with retry by collecting failed attempt and restarting
        for attempt in range(MAX_RETRIES):
            try:
                async for token in _gen():
                    yield token
                return
            except RateLimitError as exc:
                if attempt == MAX_RETRIES - 1:
                    raise
                retry_after = float(
                    getattr(exc, "retry_after", None)
                    or exc.response.headers.get("Retry-After", 2 ** attempt)
                )
                wait = retry_after * (2 ** attempt)
                await asyncio.sleep(wait)

    async def embed(self, texts: list[str]) -> list[list[float]]:
        all_embeddings: list[list[float]] = []
        for i in range(0, len(texts), EMBEDDING_BATCH_SIZE):
            batch = texts[i : i + EMBEDDING_BATCH_SIZE]
            response = await self._with_retry(
                self._client.embeddings.create,
                model=EMBEDDING_MODEL,
                input=batch,
            )
            all_embeddings.extend([item.embedding for item in response.data])
        return all_embeddings
