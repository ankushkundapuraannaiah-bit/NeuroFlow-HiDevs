from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field

import redis.asyncio as aioredis

from .base import BaseLLMProvider

logger = logging.getLogger(__name__)

ROUTER_MODELS_KEY = "router:models"


@dataclass
class RoutingCriteria:
    task_type: str  # "rag_generation" | "evaluation" | "embedding" | "classification"
    max_cost_per_call: float | None = None
    require_vision: bool = False
    require_long_context: bool = False  # > 32k tokens
    latency_budget_ms: int | None = None
    prefer_fine_tuned: bool = False
    estimated_input_tokens: int = 1000  # used for cost estimation


@dataclass
class ModelConfig:
    name: str
    provider: str
    cost_per_input_token: float   # USD per token
    cost_per_output_token: float  # USD per token
    context_window: int
    supports_vision: bool = False
    supports_fine_tuning: bool = False
    fine_tuned_for: list[str] = field(default_factory=list)
    is_judge_model: bool = False
    avg_latency_ms: float | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "ModelConfig":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})

    def estimated_cost(self, input_tokens: int, output_tokens: int = 512) -> float:
        return (
            input_tokens * self.cost_per_input_token
            + output_tokens * self.cost_per_output_token
        )


# Fallback defaults used when Redis is unavailable or empty
DEFAULT_MODELS: list[ModelConfig] = [
    ModelConfig(
        name="gpt-4o",
        provider="openai",
        cost_per_input_token=2.50 / 1_000_000,
        cost_per_output_token=10.00 / 1_000_000,
        context_window=128_000,
        supports_vision=True,
        is_judge_model=True,
    ),
    ModelConfig(
        name="gpt-4o-mini",
        provider="openai",
        cost_per_input_token=0.15 / 1_000_000,
        cost_per_output_token=0.60 / 1_000_000,
        context_window=128_000,
        supports_vision=True,
    ),
    ModelConfig(
        name="claude-opus-4-5",
        provider="anthropic",
        cost_per_input_token=15.00 / 1_000_000,
        cost_per_output_token=75.00 / 1_000_000,
        context_window=200_000,
        supports_vision=True,
        is_judge_model=True,
    ),
    ModelConfig(
        name="claude-haiku-3-5",
        provider="anthropic",
        cost_per_input_token=0.80 / 1_000_000,
        cost_per_output_token=4.00 / 1_000_000,
        context_window=200_000,
        supports_vision=False,
    ),
]


class ModelRouter:
    def __init__(self, redis_client: aioredis.Redis | None = None):
        self._redis = redis_client
        self._fallback_models = DEFAULT_MODELS

    async def _load_models(self) -> list[ModelConfig]:
        if self._redis is not None:
            try:
                raw = await self._redis.get(ROUTER_MODELS_KEY)
                if raw:
                    data = json.loads(raw)
                    return [ModelConfig.from_dict(d) for d in data]
            except Exception as exc:
                logger.warning("Failed to load models from Redis: %s", exc)
        return self._fallback_models

    async def route(
        self,
        criteria: RoutingCriteria,
        providers: dict[str, BaseLLMProvider],
    ) -> tuple[ModelConfig, BaseLLMProvider]:
        """
        Select the best (ModelConfig, BaseLLMProvider) pair for the given criteria.
        Raises ValueError if no suitable model is found.
        """
        models = await self._load_models()
        candidates = list(models)

        # --- Hard constraints ---

        # Vision requirement
        if criteria.require_vision:
            candidates = [m for m in candidates if m.supports_vision]
            if not candidates:
                raise ValueError("No vision-capable model registered.")

        # Long-context requirement (> 32k)
        if criteria.require_long_context:
            candidates = [m for m in candidates if m.context_window > 100_000]
            if not candidates:
                raise ValueError("No model with >100k context window registered.")

        # Cost cap (estimate: input_tokens + 512 output tokens)
        if criteria.max_cost_per_call is not None:
            candidates = [
                m for m in candidates
                if m.estimated_cost(criteria.estimated_input_tokens) <= criteria.max_cost_per_call
            ]
            if not candidates:
                raise ValueError(
                    f"No model fits max_cost_per_call={criteria.max_cost_per_call}"
                )

        # Latency budget — if we have latency data, filter on it
        if criteria.latency_budget_ms is not None:
            latency_filtered = [
                m for m in candidates
                if m.avg_latency_ms is None or m.avg_latency_ms <= criteria.latency_budget_ms
            ]
            if latency_filtered:
                candidates = latency_filtered
            # else: relax constraint rather than failing hard

        # --- Soft / preference rules ---

        # Evaluation tasks must use a judge model, never a fine-tuned one
        if criteria.task_type == "evaluation":
            candidates = [m for m in candidates if m.is_judge_model]
            if not candidates:
                raise ValueError("No judge model available for evaluation task.")
        elif criteria.prefer_fine_tuned:
            fine_tuned = [
                m for m in candidates
                if criteria.task_type in m.fine_tuned_for
            ]
            if fine_tuned:
                candidates = fine_tuned

        # --- Selection: cheapest model that satisfies all constraints ---
        candidates.sort(
            key=lambda m: m.estimated_cost(criteria.estimated_input_tokens)
        )
        chosen = candidates[0]

        provider = providers.get(chosen.provider)
        if provider is None:
            raise ValueError(
                f"Provider '{chosen.provider}' required by model '{chosen.name}' "
                f"is not registered in NeuroFlowClient."
            )

        logger.debug(
            "Router selected model=%s provider=%s for task=%s",
            chosen.name,
            chosen.provider,
            criteria.task_type,
        )
        return chosen, provider

    async def register_model(self, config: ModelConfig) -> None:
        """Upsert a model config in Redis (called after fine-tuning completes)."""
        if self._redis is None:
            logger.warning("No Redis client — model registration is in-memory only.")
            existing = {m.name: m for m in self._fallback_models}
            existing[config.name] = config
            self._fallback_models = list(existing.values())
            return

        models = await self._load_models()
        by_name = {m.name: m for m in models}
        by_name[config.name] = config
        updated = [vars(m) for m in by_name.values()]
        await self._redis.set(ROUTER_MODELS_KEY, json.dumps(updated))
