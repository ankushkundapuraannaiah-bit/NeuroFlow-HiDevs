from __future__ import annotations

import logging
import time
from typing import Any

import redis.asyncio as aioredis
from opentelemetry import trace
from opentelemetry.trace import Span, StatusCode

from .base import BaseLLMProvider, ChatMessage, GenerationResult
from .router import ModelRouter, RoutingCriteria

logger = logging.getLogger(__name__)

tracer = trace.get_tracer("neuroflow.providers")

METRICS_CALLS_KEY = "metrics:model:{model}:calls"
METRICS_COST_KEY = "metrics:model:{model}:cost_usd"


def _set_span_attrs(span: Span, result: GenerationResult) -> None:
    span.set_attribute("model", result.model)
    span.set_attribute("input_tokens", result.input_tokens)
    span.set_attribute("output_tokens", result.output_tokens)
    span.set_attribute("cost_usd", result.cost_usd)
    span.set_attribute("latency_ms", result.latency_ms)
    span.set_attribute("finish_reason", result.finish_reason)


class NeuroFlowClient:
    """
    Singleton facade for all LLM interactions.

    Usage:
        client = NeuroFlowClient.get_instance()
        result = await client.chat(messages, routing_criteria)
        embeddings = await client.embed(texts)
    """

    _instance: "NeuroFlowClient | None" = None

    def __init__(
        self,
        providers: dict[str, BaseLLMProvider],
        redis_url: str = "redis://localhost:6379",
        redis_client: aioredis.Redis | None = None,
    ):
        self._providers = providers
        self._redis: aioredis.Redis = redis_client or aioredis.from_url(
            redis_url, encoding="utf-8", decode_responses=True
        )
        self._router = ModelRouter(redis_client=self._redis)

    # ------------------------------------------------------------------
    # Singleton helpers
    # ------------------------------------------------------------------

    @classmethod
    def configure(
        cls,
        providers: dict[str, BaseLLMProvider],
        redis_url: str = "redis://localhost:6379",
        redis_client: aioredis.Redis | None = None,
    ) -> "NeuroFlowClient":
        cls._instance = cls(providers, redis_url, redis_client)
        return cls._instance

    @classmethod
    def get_instance(cls) -> "NeuroFlowClient":
        if cls._instance is None:
            raise RuntimeError(
                "NeuroFlowClient has not been configured. "
                "Call NeuroFlowClient.configure(...) first."
            )
        return cls._instance

    # ------------------------------------------------------------------
    # Internal: metrics
    # ------------------------------------------------------------------

    async def _track_metrics(self, result: GenerationResult) -> None:
        model = result.model
        try:
            pipe = self._redis.pipeline()
            pipe.incr(METRICS_CALLS_KEY.format(model=model))
            pipe.incrbyfloat(METRICS_COST_KEY.format(model=model), result.cost_usd)
            await pipe.execute()
        except Exception as exc:
            logger.warning("Failed to update Redis metrics for model %s: %s", model, exc)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def chat(
        self,
        messages: list[ChatMessage],
        routing_criteria: RoutingCriteria | None = None,
        *,
        provider_name: str | None = None,
        model_override: str | None = None,
        **kwargs: Any,
    ) -> GenerationResult:
        """
        Generate a chat completion.

        Either supply `routing_criteria` for automatic model selection,
        or `provider_name` + optional `model_override` for manual routing.
        """
        with tracer.start_as_current_span("neuroflow.chat") as span:
            if routing_criteria is not None:
                model_cfg, provider = await self._router.route(
                    routing_criteria, self._providers
                )
                effective_model = model_cfg.name
                span.set_attribute("routing.task_type", routing_criteria.task_type)
            else:
                if provider_name is None:
                    raise ValueError(
                        "Provide either routing_criteria or provider_name."
                    )
                provider = self._providers[provider_name]
                effective_model = model_override or getattr(provider, "model", "unknown")

            if model_override:
                kwargs["model"] = model_override
            elif routing_criteria is not None:
                kwargs.setdefault("model", effective_model)

            span.set_attribute("model.requested", effective_model)

            try:
                result = await provider.complete(messages, **kwargs)
            except Exception as exc:
                span.record_exception(exc)
                span.set_status(StatusCode.ERROR, str(exc))
                raise

            _set_span_attrs(span, result)
            span.set_status(StatusCode.OK)

        await self._track_metrics(result)
        return result

    async def embed(
        self,
        texts: list[str],
        provider_name: str = "openai",
    ) -> list[list[float]]:
        """
        Generate text embeddings using the specified provider.
        Defaults to OpenAI (the only provider currently offering embeddings).
        """
        provider = self._providers.get(provider_name)
        if provider is None:
            raise ValueError(f"Provider '{provider_name}' not registered.")

        with tracer.start_as_current_span("neuroflow.embed") as span:
            span.set_attribute("provider", provider_name)
            span.set_attribute("num_texts", len(texts))
            start = time.monotonic()

            try:
                embeddings = await provider.embed(texts)
            except Exception as exc:
                span.record_exception(exc)
                span.set_status(StatusCode.ERROR, str(exc))
                raise

            latency_ms = (time.monotonic() - start) * 1000
            span.set_attribute("latency_ms", latency_ms)
            span.set_status(StatusCode.OK)

        return embeddings

    # ------------------------------------------------------------------
    # Metrics helpers
    # ------------------------------------------------------------------

    async def get_model_metrics(self, model: str) -> dict[str, float]:
        try:
            calls_raw = await self._redis.get(METRICS_CALLS_KEY.format(model=model))
            cost_raw = await self._redis.get(METRICS_COST_KEY.format(model=model))
            return {
                "calls": float(calls_raw or 0),
                "cost_usd": float(cost_raw or 0.0),
            }
        except Exception as exc:
            logger.warning("Failed to fetch metrics for model %s: %s", model, exc)
            return {"calls": 0.0, "cost_usd": 0.0}

    async def get_all_metrics(self) -> dict[str, dict[str, float]]:
        try:
            call_keys = await self._redis.keys("metrics:model:*:calls")
            result: dict[str, dict[str, float]] = {}
            for key in call_keys:
                # key format: metrics:model:{name}:calls
                parts = key.split(":")
                model_name = parts[2]
                result[model_name] = await self.get_model_metrics(model_name)
            return result
        except Exception as exc:
            logger.warning("Failed to fetch all metrics: %s", exc)
            return {}

    @property
    def router(self) -> ModelRouter:
        return self._router

    @property
    def providers(self) -> dict[str, BaseLLMProvider]:
        return self._providers
