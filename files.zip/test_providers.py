"""
Tests for NeuroFlow provider abstraction layer.

Run with:  python -m pytest tests/test_providers.py -v
"""
import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock
import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_openai_response(content="Hello!", model="gpt-4o-mini", prompt=10, completion=20):
    resp = MagicMock()
    resp.choices = [MagicMock()]
    resp.choices[0].message.content = content
    resp.choices[0].finish_reason = "stop"
    resp.usage.prompt_tokens = prompt
    resp.usage.completion_tokens = completion
    resp.model = model
    return resp


def make_anthropic_response(text="Hi there!", model="claude-haiku-3-5", input_t=10, output_t=20):
    resp = MagicMock()
    block = MagicMock()
    block.text = text
    resp.content = [block]
    resp.usage.input_tokens = input_t
    resp.usage.output_tokens = output_t
    resp.stop_reason = "end_turn"
    resp.model = model
    return resp


# ---------------------------------------------------------------------------
# OpenAI Provider
# ---------------------------------------------------------------------------

class TestOpenAIProvider:
    def setup_method(self):
        from backend.providers.openai_provider import OpenAIProvider
        with patch("backend.providers.openai_provider.AsyncOpenAI"):
            self.provider = OpenAIProvider(api_key="test-key", model="gpt-4o-mini")

    def test_implements_interface(self):
        from backend.providers.base import BaseLLMProvider
        assert isinstance(self.provider, BaseLLMProvider)

    def test_cost_properties(self):
        assert self.provider.cost_per_input_token == pytest.approx(0.15 / 1_000_000)
        assert self.provider.cost_per_output_token == pytest.approx(0.60 / 1_000_000)

    def test_context_window(self):
        assert self.provider.context_window == 128_000

    @pytest.mark.asyncio
    async def test_complete(self):
        from backend.providers.base import ChatMessage
        mock_response = make_openai_response()
        self.provider._client.chat.completions.create = AsyncMock(return_value=mock_response)

        messages = [ChatMessage(role="user", content="Hello")]
        result = await self.provider.complete(messages)

        assert result.content == "Hello!"
        assert result.input_tokens == 10
        assert result.output_tokens == 20
        assert result.cost_usd > 0
        assert result.finish_reason == "stop"

    @pytest.mark.asyncio
    async def test_stream_yields_tokens(self):
        from backend.providers.base import ChatMessage

        async def fake_stream():
            for token in ["Hello", " world", "!"]:
                chunk = MagicMock()
                chunk.choices = [MagicMock()]
                chunk.choices[0].delta.content = token
                yield chunk

        self.provider._client.chat.completions.create = AsyncMock(return_value=fake_stream())

        messages = [ChatMessage(role="user", content="Hi")]
        tokens = []
        async for token in self.provider.stream(messages):
            tokens.append(token)

        assert tokens == ["Hello", " world", "!"]

    @pytest.mark.asyncio
    async def test_rate_limit_retry(self):
        from backend.providers.base import ChatMessage
        from openai import RateLimitError

        mock_response = make_openai_response()
        call_count = 0

        async def flaky_create(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                err = MagicMock(spec=RateLimitError)
                err.retry_after = 0  # no real sleep in tests
                err.response = MagicMock()
                err.response.headers = {"Retry-After": "0"}
                raise RateLimitError("rate limit", response=MagicMock(), body={})
            return mock_response

        self.provider._client.chat.completions.create = flaky_create

        with patch("asyncio.sleep", new_callable=AsyncMock):
            messages = [ChatMessage(role="user", content="Hi")]
            result = await self.provider.complete(messages)

        assert result.content == "Hello!"
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_embed_batches(self):
        texts = [f"text_{i}" for i in range(150)]

        call_sizes = []

        async def fake_embed(model, input):
            call_sizes.append(len(input))
            return MagicMock(data=[MagicMock(embedding=[0.1] * 10) for _ in input])

        self.provider._client.embeddings.create = AsyncMock(side_effect=fake_embed)
        embeddings = await self.provider.embed(texts)

        assert len(embeddings) == 150
        # Two batches: 100 + 50
        assert call_sizes == [100, 50]


# ---------------------------------------------------------------------------
# Anthropic Provider
# ---------------------------------------------------------------------------

class TestAnthropicProvider:
    def setup_method(self):
        from backend.providers.anthropic_provider import AnthropicProvider
        with patch("backend.providers.anthropic_provider.AsyncAnthropic"):
            self.provider = AnthropicProvider(api_key="test-key", model="claude-haiku-3-5")

    def test_implements_interface(self):
        from backend.providers.base import BaseLLMProvider
        assert isinstance(self.provider, BaseLLMProvider)

    def test_cost_properties(self):
        assert self.provider.cost_per_input_token == pytest.approx(0.80 / 1_000_000)
        assert self.provider.cost_per_output_token == pytest.approx(4.00 / 1_000_000)

    def test_context_window(self):
        assert self.provider.context_window == 200_000

    def test_split_messages_extracts_system(self):
        from backend.providers.base import ChatMessage
        messages = [
            ChatMessage(role="system", content="You are helpful."),
            ChatMessage(role="user", content="Hello"),
        ]
        system, convo = self.provider._split_messages(messages)
        assert system == "You are helpful."
        assert len(convo) == 1
        assert convo[0]["role"] == "user"

    @pytest.mark.asyncio
    async def test_complete(self):
        from backend.providers.base import ChatMessage
        mock_response = make_anthropic_response()
        self.provider._client.messages.create = AsyncMock(return_value=mock_response)

        messages = [
            ChatMessage(role="system", content="Be concise."),
            ChatMessage(role="user", content="Hello"),
        ]
        result = await self.provider.complete(messages)

        assert result.content == "Hi there!"
        assert result.input_tokens == 10
        assert result.output_tokens == 20

        # Verify system was passed as top-level param
        call_kwargs = self.provider._client.messages.create.call_args.kwargs
        assert call_kwargs.get("system") == "Be concise."
        assert all(m["role"] != "system" for m in call_kwargs["messages"])

    @pytest.mark.asyncio
    async def test_stream_yields_tokens(self):
        from backend.providers.base import ChatMessage

        async def fake_text_stream():
            for token in ["Hello", " from", " Anthropic"]:
                yield token

        stream_ctx = MagicMock()
        stream_ctx.__aenter__ = AsyncMock(return_value=stream_ctx)
        stream_ctx.__aexit__ = AsyncMock(return_value=False)
        stream_ctx.text_stream = fake_text_stream()
        self.provider._client.messages.stream = MagicMock(return_value=stream_ctx)

        messages = [ChatMessage(role="user", content="Hi")]
        tokens = []
        async for token in self.provider.stream(messages):
            tokens.append(token)

        assert tokens == ["Hello", " from", " Anthropic"]

    @pytest.mark.asyncio
    async def test_embed_raises_not_implemented(self):
        with pytest.raises(NotImplementedError):
            await self.provider.embed(["text"])


# ---------------------------------------------------------------------------
# ModelRouter
# ---------------------------------------------------------------------------

class TestModelRouter:
    def setup_method(self):
        from backend.providers.router import ModelRouter
        self.router = ModelRouter(redis_client=None)

    @pytest.mark.asyncio
    async def test_routes_vision_to_vision_model(self):
        from backend.providers.router import RoutingCriteria
        from backend.providers.openai_provider import OpenAIProvider

        with patch("backend.providers.openai_provider.AsyncOpenAI"):
            provider = OpenAIProvider(api_key="x", model="gpt-4o")

        criteria = RoutingCriteria(task_type="rag_generation", require_vision=True)
        cfg, _ = await self.router.route(criteria, {"openai": provider})
        assert cfg.supports_vision is True

    @pytest.mark.asyncio
    async def test_routes_evaluation_to_judge_model(self):
        from backend.providers.router import RoutingCriteria
        from backend.providers.openai_provider import OpenAIProvider

        with patch("backend.providers.openai_provider.AsyncOpenAI"):
            provider = OpenAIProvider(api_key="x")

        criteria = RoutingCriteria(task_type="evaluation")
        cfg, _ = await self.router.route(criteria, {"openai": provider})
        assert cfg.is_judge_model is True

    @pytest.mark.asyncio
    async def test_routes_long_context(self):
        from backend.providers.router import RoutingCriteria
        from backend.providers.openai_provider import OpenAIProvider

        with patch("backend.providers.openai_provider.AsyncOpenAI"):
            provider = OpenAIProvider(api_key="x")

        criteria = RoutingCriteria(task_type="rag_generation", require_long_context=True)
        cfg, _ = await self.router.route(criteria, {"openai": provider, "anthropic": MagicMock()})
        assert cfg.context_window > 100_000

    @pytest.mark.asyncio
    async def test_cost_cap_filters(self):
        from backend.providers.router import RoutingCriteria
        from backend.providers.openai_provider import OpenAIProvider

        with patch("backend.providers.openai_provider.AsyncOpenAI"):
            provider = OpenAIProvider(api_key="x")

        # gpt-4o-mini at 10k input + 512 output ≈ $0.0018072
        # gpt-4o at same ≈ $0.03012
        # Budget allows gpt-4o-mini but excludes gpt-4o
        budget = 0.002
        criteria = RoutingCriteria(
            task_type="classification",
            max_cost_per_call=budget,
            estimated_input_tokens=10_000,
        )
        cfg, _ = await self.router.route(criteria, {"openai": provider, "anthropic": MagicMock()})
        assert cfg.estimated_cost(10_000) <= budget
        assert cfg.name == "gpt-4o-mini"

    @pytest.mark.asyncio
    async def test_prefers_fine_tuned_model(self):
        from backend.providers.router import ModelRouter, ModelConfig, RoutingCriteria
        from backend.providers.openai_provider import OpenAIProvider

        fine_tuned = ModelConfig(
            name="ft:gpt-4o-mini:my-org:rag-v1",
            provider="openai",
            cost_per_input_token=0.20 / 1_000_000,
            cost_per_output_token=0.80 / 1_000_000,
            context_window=128_000,
            fine_tuned_for=["rag_generation"],
        )
        router = ModelRouter(redis_client=None)
        router._fallback_models = router._fallback_models + [fine_tuned]

        with patch("backend.providers.openai_provider.AsyncOpenAI"):
            provider = OpenAIProvider(api_key="x")

        criteria = RoutingCriteria(task_type="rag_generation", prefer_fine_tuned=True)
        cfg, _ = await router.route(criteria, {"openai": provider})
        assert cfg.name == "ft:gpt-4o-mini:my-org:rag-v1"


# ---------------------------------------------------------------------------
# NeuroFlowClient (metrics + span attributes)
# ---------------------------------------------------------------------------

class TestNeuroFlowClient:
    def setup_method(self):
        from backend.providers.client import NeuroFlowClient
        from backend.providers.openai_provider import OpenAIProvider

        NeuroFlowClient._instance = None

        with patch("backend.providers.openai_provider.AsyncOpenAI"):
            self.provider = OpenAIProvider(api_key="x", model="gpt-4o-mini")

        mock_redis = AsyncMock()
        mock_redis.pipeline.return_value.__aenter__ = AsyncMock()
        mock_redis.pipeline.return_value.__aexit__ = AsyncMock()
        # pipeline returns a simple mock
        pipe_mock = AsyncMock()
        pipe_mock.execute = AsyncMock(return_value=[1, 0.001])
        mock_redis.pipeline.return_value = pipe_mock
        self.mock_redis = mock_redis

        self.client = NeuroFlowClient.configure(
            providers={"openai": self.provider},
            redis_client=mock_redis,
        )

    @pytest.mark.asyncio
    async def test_chat_tracks_metrics(self):
        from backend.providers.base import ChatMessage, GenerationResult

        fake_result = GenerationResult(
            content="Hi", model="gpt-4o-mini",
            input_tokens=10, output_tokens=5,
            latency_ms=100, cost_usd=0.000002,
            finish_reason="stop",
        )
        self.provider.complete = AsyncMock(return_value=fake_result)

        messages = [ChatMessage(role="user", content="Hello")]
        result = await self.client.chat(
            messages, provider_name="openai", model_override="gpt-4o-mini"
        )

        assert result.content == "Hi"
        # Redis pipeline should have been called
        self.mock_redis.pipeline.assert_called()

    @pytest.mark.asyncio
    async def test_embed_delegates_to_provider(self):
        self.provider.embed = AsyncMock(return_value=[[0.1, 0.2]])
        embeddings = await self.client.embed(["hello"])
        assert embeddings == [[0.1, 0.2]]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
